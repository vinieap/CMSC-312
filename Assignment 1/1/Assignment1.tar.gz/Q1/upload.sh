#!/bin/bash
sftp os <<EOF

put * Assignments/1/Q1/

exit

EOF