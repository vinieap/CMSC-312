#!/bin/bash
sftp os <<EOF

put * Assignments/1/Q2/

exit

EOF