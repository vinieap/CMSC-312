#!/bin/bash
sftp os <<EOF

put * Assignments/1/Q4/

exit

EOF