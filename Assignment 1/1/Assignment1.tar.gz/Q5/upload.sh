#!/bin/bash
sftp os <<EOF

put * Assignments/1/Q5/

exit

EOF